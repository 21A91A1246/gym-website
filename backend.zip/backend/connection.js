const mongoose = require('mongoose')
// async function connection() {
//     try{
//         await mongoose.connect('mongodb://localhost:27017/gym-webdata')
//         console.log("db connected");
//     }catch(err){
//         console.error('MongoDB connection failed:', err.message);

//     }
    
// }
// const mongoose = require("mongoose");

mongoose.connect('mongodb://localhost:27017/gym-webdata')
.then(() => console.log("db connection successful"))
.catch(err=>{
    console.log(err)
})


