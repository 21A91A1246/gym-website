const express = require("express");
const router = express.Router();
const usercontroller = require('../controllers/usercontroller');

router.post('/register',(req,res)=>{
    usercontroller.doSignup(req,res)
})
router.post('/login',(req,res)=>{
    usercontroller.doLogin(req,res)
} )
//  router.post('/reset-password', (req,res)=>{
//     usercontroller.sendOtp(req,res)
//  })
module.exports = router ;
