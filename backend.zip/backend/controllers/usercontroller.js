const User = require('../models/User');
const bcrypt = require('bcryptjs')

    async function doSignup(req,res) {
    try {
        const {username , email , password , phone } = req.body ;
        console.log(username , email , password , phone);
           const user = await User.findOne({username});
        if(user){
            res.status(400).json({ success : false ,message: "username Already exist , please try with other username "})
        }else{
            const hashedPassword =  await bcrypt.hash(password , 10 )
            console.log(hashedPassword)
            const newUser = new User({username , email , password : hashedPassword  , phone });
            await newUser.save() ;

            res.status(201).json({message : "user register successfully" , success: true , data : newUser});
        }
    

    } catch (error) {
        res.status(500).json({ message: 'Error registering user'  });
        
    }
}
async function doLogin(req,res) {
    try {
        const {username, password} = req.body;
        const user = await User.findOne({username})

        if(user && await bcrypt.compare(password , user.password)){
            
            res.json({message: "login successfully" , success: "true" , user})
        }else{
            res.status(400).json({error: 'invalid credentials'})
        }
    } catch (error) {
        res.status(500).json({error:"server error"})
    }
    
}

module.exports = {
    doSignup ,
    doLogin 
}