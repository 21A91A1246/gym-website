const express = require('express');
const app = express();
const user = require('./routes/user');
const connect = require('./connection')
const cors = require('cors');
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}))
app.use(express.json());
app.use('/auth' ,user)
app.listen(4000 , (err)=>{
  if(err){
  console.log("server is not running")
  }else{
    console.log("server is running on 4000")
  }
})